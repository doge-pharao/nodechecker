//****************************************************************************
//************* ENCIENDE LEDS DESDE LA PC( PC A PIC.....)*********************
//****************************************************************************
#include <18f2550.h>
#fuses HSPLL,NOMCLR,NOWDT,NOPROTECT,NOLVP,NODEBUG,USBDIV,PLL5,CPUDIV1,VREGEN,NOPBADEN   // Para USB Ocupa cristal 20Mhz, para un reloj de 48Mhz.
#use delay (clock=48000000)

//*********************** configuracion y declaraciones ****************
#define conecta   PIN_C0
#define uno    PIN_C1
#define dos    PIN_C2
#define tres   PIN_B2
#define cuatro PIN_B1
#define cinco  PIN_B0
#define seis   PIN_C6
#define siete  PIN_C7
#define ocho   PIN_B3
#define nueve  PIN_B4

#define USB_HID_DEVICE FALSE // deshabilitamos el uso de las directivas HID
#define USB_EP1_TX_ENABLE USB_ENABLE_BULK // turn on EP1(EndPoint1) for IN bulk/interrupt transfers
#define USB_EP1_RX_ENABLE USB_ENABLE_BULK // turn on EP1(EndPoint1) for OUT bulk/interrupt transfers
#define USB_EP1_TX_SIZE 32 // size to allocate for the tx endpoint 1 buffer
#define USB_EP1_RX_SIZE 32 // size to allocate for the rx endpoint 1 buffer


#include <pic18_usb.h> // Microchip PIC18Fxx5x Hardware layer for CCS's PIC USB driver
#include "header.h" // Configuraci�n del USB y los descriptores para este dispositivo
#include <usb.c> // handles usb setup tokens and get descriptor reports


const int8 Lenbuf = 32;
int8 recbuf[Lenbuf];
char data[1];
int l1=0,l2=0,l3=0,l4=0,l5=0,l6=0,l7=0,l8=0,l9=0;
void main(void) {
  output_high(PIN_B5);
  ///apago todos los leds
  output_high(uno);
  output_high(dos);
  output_high(tres);
  output_high(cuatro);
  output_high(cinco);
  output_high(seis);
  output_high(siete);
  output_high(ocho);
  output_high(nueve);
  delay_ms(1000);
  ///enciendo todos los leds
  output_low(uno);
  output_low(dos);
  output_low(tres);
  output_low(cuatro);
  output_low(cinco);
  output_low(seis);
  output_low(siete);
  output_low(ocho);
  output_low(nueve);
  delay_ms(500);
  usb_init();
  usb_task();
  usb_wait_for_enumeration();
  enable_interrupts(global);
  output_high(PIN_C0);
  while (TRUE){
    if(usb_enumerated()){
      if (usb_kbhit(1)){
        usb_get_packet(1, recbuf, Lenbuf);
         data[0]=recbuf[0];
        switch(data[0]){
            case 'A':   output_high(uno); l1=1; break;
            case 'a':   output_low(uno); l1=0; break;
            case 'B':   output_high(dos); l2=1; break;
            case 'b':   output_low(dos); l2=0; break;
            case 'C':   output_high(tres); l3=1; break;
            case 'c':   output_low(tres); l3=0; break;
            case 'D':   output_high(cuatro); l4=1; break;
            case 'd':   output_low(cuatro); l4=0; break;
            case 'E':   output_high(cinco); l5=1; break;
            case 'e':   output_low(cinco); l5=0; break;
            case 'F':   output_high(seis); l6=1; break;
            case 'f':   output_low(seis); l6=0; break;
            case 'G':   output_high(siete); l7=1; break;
            case 'g':   output_low(siete); l7=0; break;
            case 'H':   output_high(ocho); l8=1; break;
            case 'h':   output_low(ocho); l8=0; break;
            case 'I':   output_high(nueve); l9=1; break;
            case 'i':   output_low(nueve); l9=0; break;
        }
       
        if(data[0]!='s'){
              usb_put_packet(1,data,1,USB_DTS_TOGGLE);  
        }
                     
                          
      }
    }
  }
}
