DOS: Run "NCWxx111.BAT" batch file to flash BIOS in pure DOS environment.
Windows: Run "NCWxx111.exe" to flash BIOS in Windows x86/x64 OS.
